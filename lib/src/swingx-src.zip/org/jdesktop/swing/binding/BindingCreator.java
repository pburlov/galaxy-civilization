/*
 * $Id: BindingCreator.java,v 1.2 2005/02/07 12:53:21 kleopatra Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */
package org.jdesktop.swing.binding;

import javax.swing.JComponent;

import org.jdesktop.swing.data.DataModel;

/**
 * Responsible for creating a "fitting" Binding
 * for the component.
 *
 * 
 *
 * @author Jeanette Winzenburg
 */
public interface BindingCreator {

  Binding createBinding(JComponent component, DataModel dataModel,
      String fieldName);
}
