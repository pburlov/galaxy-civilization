/*
 * DataSelectionModel.java
 *
 * Created on February 24, 2005, 6:27 AM
 */

package org.jdesktop.swing.data;

/**
 *
 * @author rb156199
 */
public interface DataSelectionModel {
    
}
