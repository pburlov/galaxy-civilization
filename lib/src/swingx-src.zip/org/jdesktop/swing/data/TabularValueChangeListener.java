/*
 * Created on 25.02.2005
 *
 */
package org.jdesktop.swing.data;

/**
 * @author (C) 2004 Jeanette Winzenburg, Berlin
 * @version $Revision: 1.1 $ - $Date: 2005/02/25 17:52:58 $
 */
public interface TabularValueChangeListener {

    void tabularValueChanged(TabularValueChangeEvent e);
}
