/*
 * $Id: Task.java,v 1.1 2005/02/27 00:24:56 rbair Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 */

package org.jdesktop.dataset.provider;

/**
 *
 * @author rb156199
 */
public interface Task extends Runnable {
    
}
